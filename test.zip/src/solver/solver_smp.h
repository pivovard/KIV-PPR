#pragma once

#include "..\common\iface\SolverIface.h"

HRESULT solve_smp(solver::TSolver_Setup &setup, solver::TSolver_Progress &progress);