#pragma once

#include <list>
#include <vector>
#include <iostream>
#include<random>

#include "../../common/iface/SolverIface.h"
#include "Country.h"

class ImperialistAlg
{
private:
	const solver::TSolver_Setup& setup;
	

public:
	std::vector<Country> pop;
	std::vector<Imperialist> imp;

	ImperialistAlg(const solver::TSolver_Setup& setup);
	~ImperialistAlg() = default;

	void init();
	void evolve();

	void write_solution();

	static std::vector<double> gen_vector(size_t size, double lower_bound, double upper_bound);
	void gen_population();

	double calc_fitness(const std::vector<double>& vec);
	void calc_fitness_all();

	void print_population();
	void print_vector(const std::vector<double>& vec);
};

