#include "..\solver_opencl.h"
#include <iostream>

HRESULT solve_opencl(solver::TSolver_Setup &setup, solver::TSolver_Progress &progress) {

	
	//az ho sem naimplementujete, pak se vrati S_OK, S_FALSE, E_INVALIDARG nebo E_FAIL dle duvod, proc volani solveru selhalo
					  //https://docs.microsoft.com/en-us/windows/win32/learnwin32/error-handling-in-com

	//kdyz uspesne najdete reseni, zapisete ho do setup.solution

	std::cout << setup.data;

	return S_FALSE;
}